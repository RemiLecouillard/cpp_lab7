1) b) On remarque que les deux algorithmes sont équivalents. On remarque aussi qu'il n'y a pas forcement 20 valeurs dans le set puisque les doublons ne sont comptés qu'une fois.

2) La capacité du vecteur est toujours multiplié par 2.

5) On en déduit que less<string> regarde l'ordre alphabétique.

6.1) La fonction make_pair permet de ne pas à avoir à préciser le type des variables que l'on insère dans la pair.
6.2) Parce que en cas d'appel à une clé non présente, la clé est créé et la valeur mappé est initialisée à 0 (dans le cas d'un type par defaut, sinon constructeur par défaut)


7) En utilisant la fonction move de l'en tête algorithm.